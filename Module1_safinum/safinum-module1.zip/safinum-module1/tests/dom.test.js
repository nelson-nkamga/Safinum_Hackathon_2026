'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const SRC = ['privacy.js', 'extractor.js', 'observer.js'].map((f) =>
  fs.readFileSync(path.join(__dirname, '..', f), 'utf8'));

// Valeurs sensibles du site de test : AUCUNE ne doit apparaître dans ce qui sort.
const SENSITIVE = ['250 000', '25 000', '225 000', '12 500', '180 000', '50 000', '7 500',
  'CM 001 2345 6789 01', 'Jean-Paul', 'Mbarga', 'Amina', 'Ngo Bell', '699123456', '6 99 12 34 56',
  'SAF-2026'];

// ── Fragments qui reproduisent la structure réelle des 5 pages ─────────────
const SHELL = (step, body) => `
<div id="app" data-v-app="">
 <div class="banner"><span>Environnement de test — données fictives, aucune transaction réelle.</span><a href="/g">Protocole de test</a></div>
 <header><div><p>Safinum Pay</p><p>Banque en ligne</p></div>
  <div><button type="button">EN</button><div><div>AN</div><span>Amina Ngo Bell</span></div></div></header>
 <ol>${['Solde', 'Frais', 'Bénéficiaire', 'Récapitulatif', 'Confirmation'].map((l, i) =>
   `<li><span class="${i + 1 === step ? 'bg-[#00BFFF] text-white' : 'bg-white'}">${i + 1}</span><span>${l}</span></li>`).join('')}</ol>
 <section id="main">${body}</section>
 <aside><h2>Votre compte</h2><p>Amina Ngo Bell</p><p>Compte courant</p><p>Solde disponible</p><p>250 000 FCFA</p>
  <p class="font-mono">CM 001 2345 6789 01</p><h2>Sécurité</h2><p>Vérifiez toujours le nom et le numéro du bénéficiaire avant de confirmer un transfert.</p></aside>
</div>`;

const BALANCE = `<p class="text-[#00BFFF]">Votre compte</p><h1>Bonjour, Amina</h1>
 <p>Consultez votre solde et lancez un transfert en toute sécurité.</p>
 <p>Solde disponible</p><p>250 000 FCFA</p><span>Numéro de compte : CM 001 2345 6789 01</span><span>Compte courant</span>
 <button><svg><path d="M1 1"/></svg> Effectuer un transfert</button><button><svg></svg> Consulter les frais</button>
 <h2>Transactions récentes</h2><p>Paiement marchand</p><p>05 nov. 2026</p><p>-12 500 FCFA</p>
 <p>Salaire reçu</p><p>04 nov. 2026</p><p>+180 000 FCFA</p><p>Transfert reçu</p><p>+50 000 FCFA</p><p>Facture électricité</p><p>-7 500 FCFA</p>`;

const FEES = `<p class="text-[#00BFFF]">Frais de transfert</p><h2>Choisissez le type de transfert et le montant. Les frais sont calculés automatiquement.</h2>
 <label>Type d'opération</label><select id="op"><option value="safinum">Compte Safinum</option><option value="mobile_money">Mobile Money</option><option value="other_bank">Autre banque</option></select>
 <p id="feeHint">Transfert instantané et gratuit</p>
 <label>Montant à envoyer</label><input id="amt" type="number" step="500"><span>FCFA</span>
 <div><span>Frais <span class="badge">Gratuit</span></span><span>0 FCFA</span></div>
 <div><span>Total à débiter</span><span id="total">25 000 FCFA</span></div>
 <div><span>Solde après opération</span><span>225 000 FCFA</span></div>
 <button><svg></svg> Retour</button><button>Continuer <svg></svg></button>`;

const BENEF = `<p class="text-[#00BFFF]">Bénéficiaire</p><h2>Renseignez les informations du destinataire. Vérifiez toujours le numéro avant de valider.</h2>
 <div class="border-amber-300 bg-amber-50 text-amber-700"><svg></svg><p>Ce bénéficiaire n'a jamais été utilisé sur ce compte. Vérifiez le numéro avant de continuer.</p></div>
 <div><label>Nom du bénéficiaire</label><div><svg></svg><input id="nm" type="text"></div></div>
 <div><label>Numéro de téléphone</label><div><svg></svg><input id="tel" type="tel"></div></div>
 <div><label>Motif du transfert</label><input type="text"></div>
 <div><label>Note (optionnel)</label><textarea rows="2"></textarea></div>
 <label><input id="chk" type="checkbox"><span>J'ai vérifié le nom et le numéro du bénéficiaire.</span></label>`;

const RECAP = `<p class="text-[#00BFFF]">Récapitulatif</p><h2>Vérifiez les informations avant de confirmer le transfert.</h2>
 <dl>
  <div><dt>Montant</dt><dd>25 000 FCFA</dd></div><div><dt>Frais</dt><dd>0 FCFA</dd></div>
  <div><dt>Total débité</dt><dd>25 000 FCFA</dd></div><div><dt>Bénéficiaire</dt><dd>Jean-Paul Mbarga</dd></div>
  <div><dt>Téléphone</dt><dd>+237 6 99 12 34 56</dd></div><div><dt><svg></svg> Référence</dt><dd>SAF-2026-IHJ3W3</dd></div>
  <div><dt>Opération</dt><dd>Compte Safinum</dd></div>
 </dl>
 <label><input type="checkbox"><span>Je confirme que les informations ci-dessus sont correctes.</span></label>
 <button>Modifier</button><button><svg></svg> Confirmer le transfert</button>`;

function setup(step, body) {
  const dom = new JSDOM(`<!doctype html><html lang="fr"><body>${SHELL(step, body)}</body></html>`,
    { runScripts: 'outside-only', pretendToBeVisual: true });
  SRC.forEach((code) => dom.window.eval(code));
  return dom;
}
const wait = (w, ms) => new Promise((r) => w.setTimeout(r, ms));

// Transport simulé : enregistre ce qui "sort" et préfixe le texte. Garde les jetons.
function makeTransport(log, mutate) {
  return async (payloads) => {
    log.push(...payloads.map((p) => p.text));
    return payloads.map((p) => ({ id: p.id, text: mutate ? mutate(p.text) : '[ew] ' + p.text }));
  };
}
const leaks = (log) => Array.from(log).filter((t) => SENSITIVE.some((s) => t.includes(s)));

test('TEST 1 — les textes sont extraits (écran Solde)', () => {
  const { window } = setup(1, BALANCE);
  const segs = window.SafinumLang.extractor.collect();
  const texts = segs.filter((s) => s.translatable).map((s) => s.masked);
  for (const t of ['Solde disponible', 'Effectuer un transfert', 'Consulter les frais', 'Transactions récentes',
    'Paiement marchand', 'Banque en ligne', 'Numéro de compte : ⟦A1⟧', 'Bonjour, ⟦N1⟧']) {
    assert.ok(texts.includes(t), 'manquant : ' + t + '\n' + texts.join('\n'));
  }
  // initiales d'avatar et bouton de langue ne sont pas extraits
  assert.ok(!segs.some((s) => s.core === 'AN' || s.core === 'EN'));
  // les montants / dates seuls ne partent pas (rien à traduire)
  assert.ok(segs.filter((s) => /FCFA|nov\./.test(s.core)).every((s) => !s.translatable));
});

test('TEST 4 — rien de sensible dans les payloads, sur les 5 écrans', () => {
  for (const [step, body] of [[1, BALANCE], [2, FEES], [3, BENEF], [4, RECAP]]) {
    const { window } = setup(step, body);
    const { extractor } = window.SafinumLang;
    const out = extractor.collect().map((s) => extractor.toPayload(s)).filter((p) => p && !p.blocked);
    assert.ok(out.length > 0);
    assert.deepEqual(leaks(Array.from(out, (p) => p.text)), [], 'fuite à l\'étape ' + step);
    assert.ok(out.every((p) => window.SafinumLang.privacy.assertSafe(p.text).safe));
  }
});

test('récapitulatif : valeurs des <dd> masquées d\'après le libellé du <dt>', () => {
  const { window } = setup(4, RECAP);
  const segs = window.SafinumLang.extractor.collect();
  const by = (core) => segs.find((s) => s.core === core);
  assert.equal(by('Jean-Paul Mbarga').masked, '⟦N1⟧');
  // un numéro (aucune lettre) n'est jamais extrait : il ne part donc pas du tout
  assert.ok(!segs.some((s) => s.core.includes('+237')));
  assert.equal(by('SAF-2026-IHJ3W3').masked, '⟦R1⟧');
  assert.equal(by('Référence').translatable, true);
  assert.equal(by('Référence').ctx.step, 4);
});

test('avertissement de sécurité : extrait en entier, niveau "warning"', () => {
  const { window } = setup(3, BENEF);
  const segs = window.SafinumLang.extractor.collect();
  const w = segs.find((s) => s.core.startsWith('Ce bénéficiaire'));
  assert.ok(w && w.translatable);
  assert.equal(w.ctx.alert, 'warning');
  assert.equal(w.masked, w.core); // aucune donnée à masquer dedans
});

test('TEST 3 — valeurs saisies et logique des formulaires intactes', async () => {
  const { window } = setup(3, BENEF);
  const d = window.document;
  const L = window.SafinumLang;
  d.getElementById('nm').value = 'Marie Kamga';
  d.getElementById('tel').value = '699123456';
  d.getElementById('chk').checked = true;
  d.querySelector('textarea').value = 'pour le loyer';
  let clicks = 0;
  d.getElementById('chk').addEventListener('click', () => clicks++);
  const log = [];
  L.observer.start({ transport: makeTransport(log) });
  await wait(window, 400);
  assert.equal(d.getElementById('nm').value, 'Marie Kamga');
  assert.equal(d.getElementById('tel').value, '699123456');
  assert.equal(d.getElementById('chk').checked, true);
  assert.equal(d.querySelector('textarea').value, 'pour le loyer');
  assert.equal(clicks, 0);
  // les libellés, eux, sont traduits
  assert.match(d.querySelector('label').textContent, /^\[ew\] Nom du bénéficiaire/);
  // et les valeurs saisies n'ont jamais quitté le navigateur
  assert.deepEqual(leaks(log).concat(log.filter((t) => /Marie|Kamga|pour le loyer/.test(t))), []);
  L.observer.stop();
});

test('<select> : options traduites, valeur sélectionnée et attributs value intacts', async () => {
  const { window } = setup(2, FEES);
  const d = window.document;
  const sel = d.getElementById('op');
  sel.value = 'mobile_money';
  window.SafinumLang.observer.start({ transport: makeTransport([]) });
  await wait(window, 400);
  assert.equal(sel.value, 'mobile_money');
  assert.deepEqual([...sel.options].map((o) => o.value), ['safinum', 'mobile_money', 'other_bank']);
  assert.match(sel.options[2].text, /\[ew\] Autre banque/);
  window.SafinumLang.observer.stop();
});

test('attributs : placeholder, aria-label, title, alt', () => {
  const { window } = setup(2, FEES + '<input placeholder="Entrez le montant" aria-label="Montant en FCFA" title="Saisir un montant"><img alt="Logo de la banque" src="x.png">');
  const segs = window.SafinumLang.extractor.collect().filter((s) => s.type === 'attr');
  assert.deepEqual(Array.from(segs, (s) => s.attr).sort(), ['alt', 'aria-label', 'placeholder', 'title']);
});

test('TEST 5 — pas de retraitement : 2e passage = 0 segment', () => {
  const { window } = setup(1, BALANCE);
  const { extractor } = window.SafinumLang;
  assert.ok(extractor.collect().length > 10);
  const before = extractor.stats().skippedSeen;
  assert.equal(extractor.collect().length, 0);
  assert.ok(extractor.stats().skippedSeen > before);
});

test('TEST 2 — nouveau contenu détecté sans recharger (changement d\'étape)', async () => {
  const { window } = setup(1, BALANCE);
  const d = window.document;
  const log = [];
  window.SafinumLang.observer.start({ transport: makeTransport(log) });
  await wait(window, 400);
  const afterFirst = log.length;
  assert.ok(afterFirst > 5);
  assert.match(d.querySelector('h1').textContent, /^\[ew\] Bonjour, Amina$/); // nom restauré

  // Vue remplace le contenu de la section (comme un clic sur "Continuer")
  d.getElementById('main').innerHTML = RECAP;
  await wait(window, 400);
  const dd = Array.from(d.querySelectorAll('dd'), (e) => e.textContent);
  assert.deepEqual(dd, ['25 000 FCFA', '0 FCFA', '25 000 FCFA', 'Jean-Paul Mbarga', '+237 6 99 12 34 56', 'SAF-2026-IHJ3W3', '[ew] Compte Safinum']);
  assert.match([...d.querySelectorAll('button')].find((b) => b.textContent.includes('Confirmer')).textContent, /\[ew\] Confirmer le transfert/);
  assert.ok(log.length > afterFirst);
  assert.deepEqual(leaks(log), []);
  window.SafinumLang.observer.stop();
});

test('anti-boucle : nos propres écritures ne relancent pas le transport', async () => {
  const { window } = setup(2, FEES);
  let calls = 0;
  window.SafinumLang.observer.start({ transport: async (ps) => { calls++; return ps.map((p) => ({ id: p.id, text: '[ew] ' + p.text })); } });
  await wait(window, 400);
  const settled = calls;
  await wait(window, 600);
  assert.equal(calls, settled);
  assert.ok(settled >= 1);
  window.SafinumLang.observer.stop();
});

test('Vue réécrit un nœud en place : il est re-traduit, sans boucle', async () => {
  const { window } = setup(2, FEES);
  const d = window.document;
  let calls = 0;
  window.SafinumLang.observer.start({ transport: async (ps) => { calls++; return ps.map((p) => ({ id: p.id, text: '[ew] ' + p.text })); } });
  await wait(window, 400);
  const hint = d.getElementById('feeHint');
  assert.match(hint.textContent, /^\[ew\] Transfert instantané et gratuit/);
  // l'utilisateur choisit "Mobile Money" : Vue change le texte en place
  hint.firstChild.nodeValue = 'Frais de 1,5 % selon le montant';
  await wait(window, 400);
  assert.equal(hint.textContent, '[ew] Frais de 1,5 % selon le montant'); // 1,5 % restauré
  const settled = calls;
  await wait(window, 500);
  assert.equal(calls, settled);
  window.SafinumLang.observer.stop();
});

test('jeton perdu par la traduction : le français est conservé', async () => {
  const { window } = setup(4, RECAP + '<p>Frais : 375 FCFA débités</p>');
  const d = window.document;
  const fb = [];
  window.SafinumLang.observer.start({
    transport: makeTransport([], (t) => '[ew] ' + t.replace(/⟦[A-Z]\d+⟧/g, '')), // le moteur « mange » les jetons
    onFallback: (s) => fb.push(s.core),
  });
  await wait(window, 400);
  const p = [...d.querySelectorAll('p')].find((e) => e.textContent.includes('375'));
  assert.equal(p.textContent, 'Frais : 375 FCFA débités'); // inchangé
  assert.ok(fb.includes('Frais : 375 FCFA débités'));
  assert.ok(window.SafinumLang.observer.stats().fallback >= 1);
  window.SafinumLang.observer.stop();
});

test('une donnée sensible qui survivrait au masquage est bloquée (jamais envoyée)', async () => {
  const { window } = setup(1, '<p>Texte test</p>');
  const L = window.SafinumLang;
  L.privacy.configure({}); // aucune règle assouplie
  const segs = L.extractor.collect(undefined, { force: true });
  const s = segs.find((x) => x.core === 'Texte test');
  s.masked = 'Total 25 000 FCFA'; // simule un défaut de masquage
  const p = L.extractor.toPayload(s);
  assert.equal(p.blocked, true);
});

test('retour au français (setEnabled false) puis re-traduction (true)', async () => {
  const { window } = setup(1, BALANCE);
  const d = window.document;
  const L = window.SafinumLang;
  L.observer.start({ transport: makeTransport([]) });
  await wait(window, 400);
  assert.match(d.querySelector('h2').textContent, /^\[ew\]/);
  await L.observer.setEnabled(false);
  assert.equal(d.querySelector('h2').textContent, 'Transactions récentes');
  assert.ok(![...d.querySelectorAll('*')].some((e) => e.children.length === 0 && e.textContent.startsWith('[ew]')));
  await L.observer.setEnabled(true);
  await wait(window, 300);
  assert.match(d.querySelector('h2').textContent, /^\[ew\] Transactions récentes/);
  L.observer.stop();
});

test('espaces de bord conservés (bouton avec icône avant le texte)', async () => {
  const { window } = setup(1, BALANCE);
  window.SafinumLang.observer.start({ transport: makeTransport([]) });
  await wait(window, 400);
  const btn = [...window.document.querySelectorAll('button')].find((b) => b.textContent.includes('Effectuer'));
  assert.equal(btn.lastChild.nodeValue, ' [ew] Effectuer un transfert');
  assert.ok(btn.querySelector('svg')); // l'icône est intacte
  window.SafinumLang.observer.stop();
});

test('getStep : étape courante lue sans dépendre de l\'URL', () => {
  for (const [n, name] of [[1, 'Solde'], [2, 'Frais'], [3, 'Bénéficiaire'], [4, 'Récapitulatif'], [5, 'Confirmation']]) {
    const { window } = setup(n, '<p>x</p>');
    assert.deepEqual(JSON.parse(JSON.stringify(window.SafinumLang.extractor.getStep())), { index: n, total: 5, label: name });
  }
});
