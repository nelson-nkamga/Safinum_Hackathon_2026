'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const p = require('../privacy.js');

const NB = '\u00A0';   // espace insécable
const NNB = '\u202F';  // fine insécable

test.beforeEach(() => p.clearSensitive());

test('montants avec devise : tous les formats du site', () => {
  for (const s of ['250 000 FCFA', '25 000 FCFA', '225 000 FCFA', '0 FCFA', '-12 500 FCFA', '+180 000 FCFA',
    `250${NB}000${NB}FCFA`, `250${NNB}000${NNB}FCFA`, '12500 FCFA']) {
    const r = p.mask(s);
    assert.equal(r.masked, '⟦M1⟧', s);
    assert.equal(p.restore(r.masked, r.vault), s);
  }
});

test('un montant dans une phrase est masqué, le texte autour est conservé', () => {
  const r = p.mask('Frais : 375 FCFA (1,5 %) le 12/11/2026 à 14h30');
  assert.equal(r.masked, 'Frais : ⟦M1⟧ (⟦P1⟧) le ⟦D1⟧ à ⟦D2⟧');
});

test('téléphone, compte, référence, date, e-mail, code', () => {
  assert.equal(p.mask('+237 6 99 12 34 56').masked, '⟦T1⟧');
  assert.equal(p.mask('699123456').masked, '⟦T1⟧');
  assert.equal(p.mask('Numéro de compte : CM 001 2345 6789 01').masked, 'Numéro de compte : ⟦A1⟧');
  assert.equal(p.mask('SAF-2026-0RGVFI').masked, '⟦R1⟧');
  assert.equal(p.mask('SAF-2026-IHJ3W3').masked, '⟦R1⟧');
  assert.equal(p.mask('05 nov. 2026').masked, '⟦D1⟧');
  assert.equal(p.mask('Contact : a.b@mail.cm').masked, 'Contact : ⟦E1⟧');
  assert.equal(p.mask('code 123456').masked, 'code ⟦X1⟧');
});

test('un montant ne doit pas être pris pour un téléphone', () => {
  assert.equal(p.mask('+180 000 FCFA').masked, '⟦M1⟧');
  assert.equal(p.mask('+50 000 FCFA').masked, '⟦M1⟧');
});

test('les textes ordinaires ne sont pas touchés', () => {
  for (const s of ['Solde disponible', 'Total à débiter', 'Compte courant', 'Compte Safinum', 'Mobile Money',
    'Safinum Pay — environnement de démonstration. Ne saisissez aucune donnée personnelle réelle.',
    'Vérifiez toujours le nom et le numéro du bénéficiaire avant de confirmer un transfert.',
    'Ce bénéficiaire n\'a jamais été utilisé sur ce compte. Vérifiez le numéro avant de continuer.']) {
    assert.equal(p.mask(s).masked, s, s);
  }
});

test('noms : salutation, heuristique, valeurs apprises', () => {
  assert.equal(p.mask('Bonjour, Amina').masked, 'Bonjour, ⟦N1⟧');
  assert.ok(p.looksLikePersonName('Jean-Paul Mbarga'));
  assert.ok(p.looksLikePersonName('Amina Ngo Bell'));
  for (const s of ['Safinum Pay', 'Compte Safinum', 'Mobile Money', 'Compte courant', 'Nouveau Transfert']) {
    assert.ok(!p.looksLikePersonName(s), s);
  }
  p.registerSensitive('Jean-Paul Mbarga', 'name');
  const r = p.mask('Transfert vers Jean-Paul Mbarga de 25 000 FCFA');
  assert.equal(r.masked, 'Transfert vers ⟦N1⟧ de ⟦M1⟧');
  // le prénom seul est aussi masqué
  assert.equal(p.mask('Merci Mbarga').masked, 'Merci ⟦N1⟧');
});

test('le même montant garde le même jeton dans une phrase', () => {
  const r = p.mask('25 000 FCFA puis encore 25 000 FCFA et 50 000 FCFA');
  assert.equal(r.masked, '⟦M1⟧ puis encore ⟦M1⟧ et ⟦M2⟧');
});

test('aller-retour mask → restore', () => {
  const src = 'Vous envoyez 25 000 FCFA à +237 6 99 12 34 56 (réf. SAF-2026-0RGVFI) le 05 nov. 2026';
  const r = p.mask(src);
  assert.ok(!/\d{3}/.test(r.masked), r.masked);
  assert.equal(p.restore(r.masked, r.vault), src);
});

test('restore tolère des délimiteurs abîmés par le moteur', () => {
  const r = p.mask('Frais : 375 FCFA');
  assert.equal(p.restore('xx [M1] yy', r.vault), 'xx 375 FCFA yy');
  assert.equal(p.restore('xx ⟦ M1 ⟧ yy', r.vault), 'xx 375 FCFA yy');
  assert.equal(p.restore('xx ⟦M9⟧ yy', r.vault), 'xx ⟦M9⟧ yy'); // inconnu : laissé tel quel
});

test('validate : jeton perdu, dupliqué ou inventé', () => {
  const r = p.mask('Total 25 000 FCFA pour +237 6 99 12 34 56');
  assert.equal(p.validate(r.masked, 'a ⟦M1⟧ b ⟦T1⟧', r.vault).ok, true);
  assert.deepEqual(p.validate(r.masked, 'a ⟦M1⟧ b', r.vault).missing, ['⟦T1⟧']);
  assert.deepEqual(p.validate(r.masked, 'a ⟦M1⟧ ⟦M1⟧ b ⟦T1⟧', r.vault).duplicated, ['⟦M1⟧']);
  assert.deepEqual(p.validate(r.masked, 'a ⟦M1⟧ b ⟦T1⟧ ⟦M7⟧', r.vault).extra, ['⟦M7⟧']);
});

test('assertSafe : un texte bien masqué passe, un texte brut est bloqué', () => {
  assert.equal(p.assertSafe(p.mask('Frais : 375 FCFA à Jean 699123456').masked).safe, true);
  const bad = p.assertSafe('Total 25 000 FCFA');
  assert.equal(bad.safe, false);
  assert.ok(bad.leaks[0].sample.length <= 3); // pas de fuite dans le rapport lui-même
});

test('hasTranslatableText : rien à traduire si le texte n\'est que des jetons', () => {
  assert.equal(p.hasTranslatableText('⟦M1⟧'), false);
  assert.equal(p.hasTranslatableText('⟦D1⟧'), false);
  assert.equal(p.hasTranslatableText('Frais : ⟦M1⟧'), true);
});

test('forceKind : valeur entière masquée quel que soit son format', () => {
  const r = p.mask('Tante Marie (Douala)', { forceKind: 'name' });
  assert.equal(r.masked, '⟦N1⟧');
  assert.equal(p.restore(r.masked, r.vault), 'Tante Marie (Douala)');
});
